/**
 * 
 */
/**
 * @author TT
 *
 */
module domashnaRabota1 {
}