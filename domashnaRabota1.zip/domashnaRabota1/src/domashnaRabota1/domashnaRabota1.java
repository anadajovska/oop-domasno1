package domashnaRabota1;

public class domashnaRabota1 {
	public static void main(String[] args) {
		System.out.println("Hello World OOP FIKT");
	}
}
